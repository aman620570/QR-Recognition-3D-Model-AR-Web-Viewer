/* App Layout */
.App {
    text-align: center;
    font-family: Arial, sans-serif;
  }
  
  .App-header {
    background-color: #282c34;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    font-size: calc(10px + 2vmin);
    color: white;
  }
  
  .ar-container {
    width: 100%;
    max-width: 500px;
    margin: 20px auto;
    padding: 20px;
    background: #fff;
    border-radius: 15px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
  }
  
  .qr-reader {
    width: 100%;
    height: auto;
  }
  
  .toast {
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background-color: rgba(255, 0, 0, 0.8);
    color: white;
    padding: 12px 24px;
    border-radius: 25px;
    font-size: 1.2rem;
    display: none;
    opacity: 0;
    transition: opacity 0.3s ease-in-out;
  }
  
  .toast.show {
    display: block;
    opacity: 1;
  }
  
  /* Media Queries */
  @media (max-width: 600px) {
    .ar-container {
      padding: 15px;
    }
  
    .App-header h1 {
      font-size: 1.5rem;
    }
  }
  